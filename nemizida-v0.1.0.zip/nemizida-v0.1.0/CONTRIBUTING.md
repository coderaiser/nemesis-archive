Contributing
If you would like to contribute - send pull request to dev branch. Getting dev version of Minify:

    git clone git://github.com/coderaiser/nemizida.git
    git checkout dev

or by [link](https://github.com/coderaiser/nemizida/tree/dev).