Nemizida v0.1.0
===========
[![Flattr][FlattrIMGURL]][FlattrURL]
[FlattrIMGURL]:             http://api.flattr.com/button/flattr-badge-large.png
[FlattrURL]:                https://flattr.com/submit/auto?user_id=coderaiser&url=github.com/coderaiser/nemizida&title=nemizida&language=&tags=github&category=software

Nemizida x86 operation system writen on fasm.
You can find more [inforamation](http://n3m1z1d4.pp.net.ua "information")
or watch [demo](http://nemizida.cloudfoundry.com "Nemizida")
