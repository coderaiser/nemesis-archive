#/bin/sh

rm -rf dos* mtools* fasm* *.bin kernel/*bin shell/*bin node*